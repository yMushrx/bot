const Discord = require("discord.js");
const { JsonDatabase } = require("wio.db");
const config = new JsonDatabase({ databasePath: "./config.json" });
const perms = new JsonDatabase({
  databasePath: "./databases/myJsonPerms.json",
});
const db = new JsonDatabase({
  databasePath: "./databases/myJsonPainel.json",
});
const debe = require("../databases/myJsonPainel.json");
const prod = new JsonDatabase({
  databasePath: "./databases/myJsonProdutos.json",
});

module.exports = {
  name: 'config_painel',
  async execute(interaction, message, client) {
    if (interaction.isButton()) {
      const customId = interaction.customId;
      const id = customId.split("_")[0];

      if (customId.endsWith('_config_painel_embed')) {
        const eprod = db.get(id);

        interaction.update({
          embeds: [
            new Discord.EmbedBuilder()
              .setTitle(`Titulo Atual: ${db.get(`${id}.configuração.titulo`)}`)
              .setDescription(`**DESCRIÇÃO ATUAL: ${db.get(`${id}.configuração.descrição`)}**`)
              .addFields(
                {
                  name: `Cor da embed:`,
                  value: `${db.get(`${id}.configuração.Cor_Embed`)}`,
                  inline: true
                },
                {
                  name: `PlaceHolder`,
                  value: `${db.get(`${id}.configuração.placeholder`)}`,
                  inline: true
                },
                {
                  name: `RodaPé:`,
                  value: `${db.get(`${id}.configuração.footer`)}`,
                  inline: true
                },
                {
                  name: `Banner URL: `,
                  value: `${db.get(`${id}.configuração.banner`)}`,
                  inline: true
                },)
              ],
            components: [
              new Discord.ActionRowBuilder()
                .addComponents(
                  new Discord.StringSelectMenuBuilder()
                    .setPlaceholder(`Altere Alguma coisa`)
                    .setCustomId(`${id}_selectmenu_embed`)
                    .addOptions(
                      {
                        label: `Alterar Titulo`,
                        value: `${id}_alterar_titulo`
                      },
                      {
                        label: `Alterar Descrição`,
                        value: `${id}_alterar_descrição`
                      },
                      {
                        label: `Alterar Cor da embed`,
                        value: `${id}_alterar_embed_color`
                      },
                      {
                        label: `Alterar PlaceHolder`,
                        value: `${id}_alterar_placeholder`
                      },
                      {
                        label: `Alterar RodaPé`,
                        value: `${id}_alterar_rodape`
                      },
                      {
                        label: `Alterar Banner`,
                        value: `${id}_alterar_banner`
                      },
                      {
                        label: `Atualizar`,
                        value: `${id}_atualizar`
                      },
                      {
                        label: `Voltar`,
                        value: `${id}_voltar`
                      },
                    )
                )
            ]
          });
          const filter = (i) => i.user.id === interaction.user.id;
          const interação = interaction.message.createMessageComponentCollector({ filter });
      
          interação.on("collect", async (interaction) => {
            if (interaction.user.id != interaction.user.id) {
              return;
            }
      
            if (interaction.customId === `${id}_selectmenu_embed`) {

              const options = interaction.values[0]

              if(options === `${id}_alterar_titulo`){

                interaction.deferUpdate();
        interaction.channel.send("<:info2:1172016307814801408> | Qual o novo Titulo?").then((msg) => {
          const filter = (m) => m.author.id === interaction.user.id;
          const collector = msg.channel.createMessageCollector({
            filter,
            max: 1,
          });
          collector.on("collect", (message) => {
            message.delete();
            db.set(`${id}.configuração.titulo`, `${message.content.replace(",", ".")}`);
            msg.edit("<:config2:1172016353692110870> | Alterado!");
          });
        });
                

              }

              if(options === `${id}_alterar_descrição`){

                interaction.deferUpdate();
                interaction.channel.send("<:info2:1172016307814801408> | Qual a nova descrição?").then((msg) => {
                  const filter = (m) => m.author.id === interaction.user.id;
                  const collector = msg.channel.createMessageCollector({
                    filter,
                    max: 1,
                  });
                  collector.on("collect", (message) => {
                    message.delete();
                    db.set(`${id}.configuração.descrição`, `${message.content.replace(",", ".")}`);
                    msg.edit("<:config2:1172016353692110870> | Alterado!");
                  });
                });

              }

              if(options === `${id}_alterar_embed_color`){

                interaction.deferUpdate();
                interaction.channel.send("<:info2:1172016307814801408> | Qual e a nova?").then((msg) => {
                  const filter = (m) => m.author.id === interaction.user.id;
                  const collector = msg.channel.createMessageCollector({
                    filter,
                    max: 1,
                  });
                  collector.on("collect", (message) => {
                    message.delete();
                    db.set(`${id}.configuração.Cor_Embed`, `${message.content.replace(",", ".")}`);
                    msg.edit("<:config2:1172016353692110870> | Alterado!");
                  });
                });

              }

              if(options === `${id}_alterar_rodape`){

                interaction.deferUpdate();
                interaction.channel.send("<:info2:1172016307814801408> | Qual é o novo rodapé?").then((msg) => {
                  const filter = (m) => m.author.id === interaction.user.id;
                  const collector = msg.channel.createMessageCollector({
                    filter,
                    max: 1,
                  });
                  collector.on("collect", (message) => {
                    message.delete();
                    db.set(`${id}.configuração.footer`, `${message.content.replace(",", ".")}`);
                    msg.edit("<:config2:1172016353692110870> | Alterado!");
                  });
                });


              }

              if(options === `${id}_alterar_placeholder`){

                interaction.deferUpdate();
                interaction.channel.send("<:info2:1172016307814801408> | Qual o novo placeholder?").then((msg) => {
                  const filter = (m) => m.author.id === interaction.user.id;
                  const collector = msg.channel.createMessageCollector({
                    filter,
                    max: 1,
                  });
                  collector.on("collect", (message) => {
                    message.delete();
                    db.set(`${id}.configuração.placeholder`, `${message.content.replace(",", ".")}`);
                    msg.edit("<:config2:1172016353692110870> | Alterado!");
                  });
                });

              }

              if(options === `${id}_alterar_banner`){

                interaction.deferUpdate();
                interaction.channel.send("<:info2:1172016307814801408> | Qual o novo banner?").then((msg) => {
                  const filter = (m) => m.author.id === interaction.user.id;
                  const collector = msg.channel.createMessageCollector({
                    filter,
                    max: 1,
                  });
                  collector.on("collect", (message) => {
                    message.delete();
                    db.set(`${id}.configuração.banner`, `${message.content.replace(",", ".")}`);
                    msg.edit("<:config2:1172016353692110870> | Alterado!");
                  });
                });


              }

              if(options === `${id}_atualizar`){

                interaction.update({
                  embeds: [
                    new Discord.EmbedBuilder()
                      .setTitle(`Titulo Atual: ${db.get(`${id}.configuração.titulo`)}`)
                      .setDescription(`**DESCRIÇÃO ATUAL: ${db.get(`${id}.configuração.descrição`)}**`)
                      .addFields(
                        {
                          name: `Cor da embed:`,
                          value: `${db.get(`${id}.configuração.Cor_Embed`)}`,
                          inline: true
                        },
                        {
                          name: `PlaceHolder`,
                          value: `${db.get(`${id}.configuração.placeholder`)}`,
                          inline: true
                        },
                        {
                          name: `RodaPé:`,
                          value: `${db.get(`${id}.configuração.footer`)}`,
                          inline: true
                        },
                        {
                          name: `Banner URL: `,
                          value: `${db.get(`${id}.configuração.banner`)}`,
                          inline: true
                        },)
                      ],})

              }

              if(options === `${id}_voltar`){
                const row = 
                new Discord.ActionRowBuilder()
                .addComponents(
                  new Discord.ButtonBuilder()
                      .setLabel("Configurar embed")
                      .setCustomId(`${id}_config_painel_embed`)
                      .setEmoji("<:copy:1172263103031951481>")
                      .setStyle(Discord.ButtonStyle.Secondary),
                      new Discord.ButtonBuilder()
                      .setLabel("Configurar Produtos")
                      .setCustomId(`${id}_configproductspainel`)
                      .setEmoji("<:cxb:1172016413091831880>")
                      .setStyle(Discord.ButtonStyle.Secondary),
                      new Discord.ButtonBuilder()
                      .setLabel("DELETAR")
                      .setCustomId(`${id}_delete_painel`)
                      .setEmoji("<:lixo:1172221753393676381>")
                      .setStyle(Discord.ButtonStyle.Secondary),
                );
                
                  
              
                  const adici = new Discord.EmbedBuilder()
                    .setTitle(`${config.get(`title`)} | Gerenciar Painel`)
                    .setDescription(`Escolha oque deseja Gerenciar:`)
                    .setFooter({ text: `${interaction.guild.name} - Todos os direitos reservados.`,iconURL: interaction.client.user.displayAvatarURL()})
                  interaction.update({ embeds: [adici], components: [row] });

              }

              
            }
          }
            )
        if (!eprod) return;
      } else if (customId.endsWith('_configproductspainel')) {
        const eprod = db.get(id);
        const idproduto = db.get(`${id}.idproduto`);

        const fields = [];
        for (const produtoId in idproduto) {
            const produtoInfo = prod.get(produtoId);
            if (produtoInfo) {
                fields.push({
                    name: produtoInfo.nome,
                    value: produtoInfo.idproduto,
                    inline:true
                });
            }
        }

        interaction.update({ embeds:[
            new Discord.EmbedBuilder()
            .setTitle(`Aqui Está Todos os produtos:`)
            .addFields(...fields)
            .setFooter({ text:`Estão separado por nome/id`})
        ],
        components:[
            new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.ButtonBuilder()
                .setCustomId("adicionar_produto_painel")
                .setEmoji("<:mais:1172016328526278667>")
                .setLabel("Adicionar um Produto")
                .setStyle(Discord.ButtonStyle.Secondary),
                new Discord.ButtonBuilder()
                .setCustomId("remover_produto_painel")
                .setEmoji("<:1150929660490809404:1172016427755114566>")
                .setLabel("Remover um Produto")
                .setStyle(Discord.ButtonStyle.Secondary),
                new Discord.ButtonBuilder()
                .setCustomId("voltar1")
                .setEmoji("<:config2:1172016353692110870>")
                .setLabel("Voltar")
                .setStyle(Discord.ButtonStyle.Secondary),
            )
        ]});


        const filter = (i) => i.user.id === interaction.user.id;
          const interação = interaction.message.createMessageComponentCollector({ filter });
      
          interação.on("collect", async (interaction) => {
            if (interaction.user.id != interaction.user.id) {
              return;
            }
          
            if(interaction.customId === "adicionar_produto_painel") { 
              
              interaction.deferUpdate();
                interaction.channel.send("<:info2:1172016307814801408> | Qual o novo produto?").then((msg) => {
                  const filter = (m) => m.author.id === interaction.user.id;
                  const collector = msg.channel.createMessageCollector({
                    filter,
                    max: 1,
                  });
                  collector.on("collect", (message) => {
                    const idproduto = message.content.replace(",", ".");
                    if (message.content !== `${prod.get(`${message.content}.idproduto`)}`){
                      interaction.channel.send({
                        content:`Produto não existe!`
                      })
                      message.delete();
                      setTimeout(() => {
                        msg.delete()
                      }, 5000);
                    }
                    else {
                    message.delete();
                    db.set(`${id}.idproduto.${idproduto}`, idproduto);
                    msg.edit("<:config2:1172016353692110870> | Adicionado!");
                    setTimeout(() => {
                      msg.delete()
                    }, 5000);
                    }
                  });
                });

            }

            if(interaction.customId === "remover_produto_painel") {
              
              
              interaction.deferUpdate();
                interaction.channel.send("<:info2:1172016307814801408> | Qual produto você deseja remover?").then((msg) => {
                  const filter = (m) => m.author.id === interaction.user.id;
                  const collector = msg.channel.createMessageCollector({
                    filter,
                    max: 1,
                  });
                  collector.on("collect", (message) => {
                    const idproduto = message.content.replace(",", ".");
                    if (message.content !== `${db.get(`${id}.idproduto.${idproduto}`)}`){
                      interaction.channel.send({
                        content:`Não encontrei o produto no painel!`
                      })
                      message.delete();
                      setTimeout(() => {
                        msg.delete()
                      }, 5000);
                    }
                    else {

                    message.delete();
                    db.delete(`${id}.idproduto.${idproduto}`);
                    msg.edit("<:config2:1172016353692110870> | Removido!");
                    setTimeout(() => {
                      msg.delete()
                    }, 5000);
                    }
                  });
                });
                return;

            }


            if(interaction.customId === "voltar1"){
              

              const row = 
        new Discord.ActionRowBuilder()
        .addComponents(
          new Discord.ButtonBuilder()
              .setLabel("Configurar embed")
              .setCustomId(`${id}_config_painel_embed`)
              .setEmoji("<:copy:1172263103031951481>")
              .setStyle(Discord.ButtonStyle.Secondary),
              new Discord.ButtonBuilder()
              .setLabel("Configurar Produtos")
              .setCustomId(`${id}_configproductspainel`)
              .setEmoji("<:cxb:1172016413091831880>")
              .setStyle(Discord.ButtonStyle.Secondary),
              new Discord.ButtonBuilder()
              .setLabel("DELETAR")
              .setCustomId(`${id}_delete_painel`)
              .setEmoji("<:lixo:1172221753393676381>")
              .setStyle(Discord.ButtonStyle.Secondary),
        );
        
          
      
          const adici = new Discord.EmbedBuilder()
            .setTitle(`${config.get(`title`)} | Gerenciar Painel`)
            .setDescription(`Escolha oque deseja Gerenciar:`)
            .setColor(config.get(`color`))
            .setFooter({ text: `${interaction.guild.name} - Todos os direitos reservados.`,iconURL: interaction.client.user.displayAvatarURL()})
          interaction.update({ embeds: [adici], components: [row], ephemeral:true });


            }

          
          })

        if (!eprod) return;
    }else if (customId.endsWith('_delete_painel')) {
        const eprod = db.get(id);
        

        db.delete(id)
        
        interaction.update({
            content:`Deletado Com Sucesso`,
            components:[],
            embeds:[]
        });
        
        if (!eprod) return;
      }
    }
  }
}
