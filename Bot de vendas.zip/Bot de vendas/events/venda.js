const Discord = require("discord.js");
const client = new Discord.Client({ intents: 32767 });
const axios = require("axios")
const moment = require("moment")
const { WebhookClient } = require("discord.js")
const confud = require("../config.json")

const { JsonDatabase, } = require("wio.db");
const db = new JsonDatabase({ databasePath:"./databases/myJsonProdutos.json" });
const dbc = new JsonDatabase({ databasePath:"./databases/myJsonCupons.json" });
const db2 = new JsonDatabase({ databasePath:"./databases/myJsonDatabase.json" });
const db3 = new JsonDatabase({ databasePath:"./databases/myJsonIDs.json" });
const perms = new JsonDatabase({ databasePath:"./databases/myJsonPerms.json" });
const config = new JsonDatabase({ databasePath:"./config.json" });



module.exports = {
    name: 'botconfig',
    async execute(interaction, message, client) {
moment.locale("pt-br");




  if (interaction.isButton()) {
    const eprod = db.get(interaction.customId);

    const ususus = interaction.user
      if (!eprod) return;
      const severi = interaction.customId;
      
        if (eprod) {
          const quantidade = db.get(`${severi}.conta`).length;
          const row = new Discord.ActionRowBuilder()
           .addComponents(
             new Discord.ButtonBuilder()
               .setCustomId(interaction.customId)
               .setLabel('Adicionar ao Carrinho')
               
               .setStyle(Discord.ButtonStyle.Secondary),
        );
            
        const embed = new Discord.EmbedBuilder()
          .setTitle(`${config.get(`title`)}`)
          .setDescription(`
\`\`\`
${db.get(`${interaction.customId}.desc`)}
\`\`\`
**<:copy:1172263103031951481> | Nome:** __${db.get(`${interaction.customId}.nome`)}__
**<:cedulas:1172016314743787550> | Preço:** __${db.get(`${interaction.customId}.preco`)}__
**<:cxb:1172016413091831880> | Estoque:** __${db.get(`${interaction.customId}.conta`).length}__`)
                            .setColor(config.get(`color`))
                            .setImage(`https://static-prod.adweek.com/wp-content/uploads/2021/07/DiscordLogo-652x367.jpg`)
                            .setThumbnail(
              `${interaction.client.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
        interaction.message.edit({ embeds: [embed], components: [row] })
            
        if (quantidade < 1) {
          const embedsemstock = new Discord.EmbedBuilder()
            .setTitle(`${config.get(`title`)}`)
            .setDescription(`<:copy:1172263103031951481> **| Este produto está sem estoque no momento, volte mais tarde!**`)
            .setColor(config.get(`color`))
          interaction.reply({ embeds: [embedsemstock], ephemeral: true })
          return;
        }
            
        interaction.deferUpdate()
        if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) {
          return;
        }
            
        interaction.guild.channels.create({
            name:`🛒・${interaction.user.username}`,
          type: 0,
          parent: config.get(`category`),
          topic: interaction.user.id,
          permissionOverwrites: [
            {
              id: interaction.guild.id,
              deny: ["ViewChannel"]
            },
            {
             id: confud.role_approved,
             allow: [
                "ViewChannel",
                "SendMessages",
                "AttachFiles",
                "AddReactions",
              ],
            },
            {
             id: interaction.user.id,
             allow: [
                "ViewChannel",
                "SendMessages",
                "AttachFiles",
                "AddReactions",
              ],
           }
         ]
       }).then(c => {
           let quantidade1 = 1;
           let precoalt = eprod.preco;
           var data_id = Math.floor(Math.random() * 999999999999999);
           db3.set(`${data_id}.id`, `${data_id}`)
           db3.set(`${data_id}.status`, `Pendente (1)`)
           db3.set(`${data_id}.userid`, `${interaction.user.id}`)
           db3.set(`${data_id}.dataid`, `${moment().format('LLLL')}`)
           db3.set(`${data_id}.nomeid`, `${eprod.nome}`)
           db3.set(`${data_id}.qtdid`, `${quantidade1}`)
           db3.set(`${data_id}.precoid`, `${precoalt}`)
           db3.set(`${data_id}.entrid`, `Andamento`)
           const timer2 = setTimeout(function () {
             if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) { c.delete(); }
             db3.delete(`${data_id}`)
           }, 300000)
                     
           const row = new Discord.ActionRowBuilder()
             .addComponents(
               new Discord.ButtonBuilder()
                 .setCustomId('removeboton')
                 .setLabel('Remover Produto')
                 
                 .setStyle(Discord.ButtonStyle.Secondary),
           )
             .addComponents(
               new Discord.ButtonBuilder()
                 .setCustomId('comprarboton')
                 .setLabel('Ir Para o Pagamento')
                
                 .setStyle(Discord.ButtonStyle.Secondary),
           )
             .addComponents(
               new Discord.ButtonBuilder()
                 .setCustomId('addboton')
                 .setLabel('Adicionar Produto')
                 
                 .setStyle(Discord.ButtonStyle.Secondary),
           )
             .addComponents(
               new Discord.ButtonBuilder()
                 .setCustomId('cancelarbuy')
                 .setLabel('Cancelar a Compra')
                 
                 .setStyle(Discord.ButtonStyle.Secondary),
           );
           const embedss = new Discord.EmbedBuilder()
             .setTitle(`${config.get(`title`)}`)
             .addFields({name: `<:copy:1172263103031951481> **| Nome:**`, value: eprod.nome})
             .addFields({name: `<:cxb:1172016413091831880> **| Quantidade:**`, value:`${quantidade1}`})
             .addFields({name: `<:cedulas:1172016314743787550> **| Valor:**`, value:`${precoalt} `}) 
             .addFields({name: `<:rg:1172016364014284820> **| ID da compra:**`,value: `${data_id}`}) 
             .setColor(config.get(`color`))
             .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
           c.send({ embeds: [embedss], content: `<@${interaction.user.id}>`, components: [row], fetchReply: true }).then(msg => {
             const filter = i => i.user.id === interaction.user.id;
             const collector = msg.createMessageComponentCollector({ filter });
             collector.on("collect", intera => {
               intera.deferUpdate()
               if (intera.customId === 'cancelarbuy') {
                 clearInterval(timer2);
                 const embedcancelar = new Discord.EmbedBuilder()
                            .setTitle(`${config.get(`title`)}`)
                            .setDescription(`<:1150929660490809404:1172016427755114566> **| Você cancelou a compra e o stock foi devolvido a loja novamente!**`)
                            .setColor(config.get(`color`))
                            .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                            interaction.user.send({embeds: [embedcancelar]})
                 db3.delete(`${data_id}`)
                 if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) { c.delete(); }
               }
               if (intera.customId === "addboton") {
                 if (quantidade1++ >= quantidade) {
                   quantidade1--;
                   const embedss2 = new Discord.EmbedBuilder()
                     .setTitle(`${config.get(`title`)}`)
                     .addFields({name: `<:copy:1172263103031951481> **| Nome:**`,value: `${eprod.nome}`})
                     .addFields({name: `<:cxb:1172016413091831880> **| Quantidade:**`,value: `${quantidade1}`})
                     .addFields({name: `<:cedulas:1172016314743787550> **| Valor:**`, value: `${precoalt} `}) 
                     .addFields({name: `<:rg:1172016364014284820> **| ID da compra:**`,value: `${data_id}`}) 
                     .setColor(config.get(`color`))
                     .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                   msg.edit({ embeds: [embedss2] })
                 } else {
                   precoalt = Number(precoalt) + Number(eprod.preco);
                   const embedss = new Discord.EmbedBuilder()
                     .setTitle(`${config.get(`title`)}`)
                     .addFields({name: `<:copy:1172263103031951481> **| Nome:**`,value: `${eprod.nome}`})
                     .addFields({name: `<:cxb:1172016413091831880> **| Quantidade:**`,value: `${quantidade1}`})
                     .addFields({name: `<:cedulas:1172016314743787550> **| Valor:**`,value: `${precoalt} `}) 
                     .addFields({name: `<:rg:1172016364014284820> **| ID da compra:**`,value: `${data_id}`}) 
                     .setColor(config.get(`color`))
                     .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                   msg.edit({ embeds: [embedss] })
                 }
               }
                 if (intera.customId === "removeboton") {
                   if (quantidade1 <= 1) {
                     } else {
                       precoalt = precoalt - eprod.preco;
                       quantidade1--;
                       const embedss = new Discord.EmbedBuilder()
                         .setTitle(`${config.get(`title`)}`)                        
                         .addFields({name: `<:copy:1172263103031951481> **| Nome:**`,value: `${eprod.nome}`})
                         .addFields({name: `<:cxb:1172016413091831880> **| Quantidade:**`,value: `${quantidade1}`})
                         .addFields({name: `<:cedulas:1172016314743787550> **| Valor:**`,value: `${precoalt} `}) 
                         .addFields({name: `<:rg:1172016364014284820> **| ID da compra:**`,value: `${data_id}`}) 
                         .setColor(config.get(`color`))
                         .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                       msg.edit({ embeds: [embedss] })
                     }
                   }
                 
                   if (intera.customId === "comprarboton") {
                    // msg.channel.bulkDelete(50);
                    // clearInterval(timer2);
                    // const timer3 = setTimeout(function () {
                    //  if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) { c.delete(); }
                    //   db3.delete(`${data_id}`)
                    //  }, 300000)
                     const row = new Discord.ActionRowBuilder()
                       .addComponents(
                         new Discord.ButtonBuilder()
                           .setCustomId('addcboton')
                           .setLabel('Adicionar Cupom')
                           
                           .setStyle(Discord.ButtonStyle.Secondary),
                     )
                       .addComponents(
                         new Discord.ButtonBuilder()
                           .setCustomId('continuarboton')
                           .setLabel('Ir Para o Pagamento')
                           
                           .setStyle(Discord.ButtonStyle.Secondary),
                     )
                       .addComponents(
                         new Discord.ButtonBuilder()
                           .setCustomId('cancelarboton')
                           .setLabel('Cancelar a Compra')
                           
                           
                           .setStyle(Discord.ButtonStyle.Secondary),
                     );
                                        
                     const embedss = new Discord.EmbedBuilder()
                       .setTitle(`${config.get(`title`)}`)
                       .addFields({name: `<:cxb:1172016413091831880> **| Cupom:**`,value: `Nenhum`})
                       .addFields({name: `<:copy:1172263103031951481> **| Desconto:**`,value: `0.00%`})
                       .addFields({name: `<:cedulas:1172016314743787550> **| Preço Atual:**`, value: `${precoalt}`}) 
                       .setColor(config.get(`color`))
                       .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                     msg.edit({ embeds: [embedss], components: [row], content: `<@${interaction.user.id}>`, fetchReply: true }).then(msg => {
                       const filter = i => i.user.id === interaction.user.id;
                       const collector = msg.createMessageComponentCollector({ filter });
                       collector.on("collect", intera2 => {
                         intera2.deferUpdate()
                         if (intera2.customId === 'addcboton') {
                           
                            msg.channel.send("<:info2:1172016307814801408> **| Qual o cupom?**").then(mensagem => {
                             const filter = m => m.author.id === interaction.user.id;
                             const collector = mensagem.channel.createMessageCollector({ filter, max: 1 });
                             collector.on("collect", cupom => {
                               if(`${cupom}` !== `${dbc.get(`${cupom}.idcupom`)}`) {
                                 cupom.delete()
                                 mensagem.edit("<:1150929660490809404:1172016427755114566> **| Isso não é um cupom!**")
                                 
                                 return;
                               }
                                 
                               var minalt = dbc.get(`${cupom}.minimo`);
                               var dscalt = dbc.get(`${cupom}.desconto`);
                               var qtdalt = dbc.get(`${cupom}.quantidade`);
                                 
                               precoalt = Number(precoalt) + Number(`1`);
                               minalt = Number(minalt) + Number(`1`);
                               if(precoalt < minalt) {
                                 cupom.delete()
                                 
                                 mensagem.edit(`<:1150929660490809404:1172016427755114566> **| Você não atingiu o mínimo!**`)
                                 return;
                               } else {
                              
                               precoalt = Number(precoalt) - Number(`1`);
                               minalt = Number(minalt) - Number(`1`);
                                   
                               if(`${dbc.get(`${cupom}.quantidade`)}` === "0") {
                                 cupom.delete()
                                 
                                 mensagem.edit("<:1150929660490809404:1172016427755114566> **| Esse cupom saiu de estoque!**")
                                 return;
                               }
                                              
                               if(`${cupom}` === `${dbc.get(`${cupom}.idcupom`)}`) {
                                 cupom.delete()
                                 mensagem.edit("<:1150929512859697152:1172016425469231196> **| Cupom adicionado com sucesso.**")
                                  
                                   var precinho = precoalt;
                                   var descontinho = "0."+dscalt;
                                   var cupomfinal = precinho * descontinho;
                                   precoalt = precinho - cupomfinal;
                                   qtdalt = qtdalt - 1;
                                   row.components[0].setDisabled(true)
                                   const embedss2 = new Discord.EmbedBuilder()
                                     .setTitle(`${config.get(`title`)}`)
                                     .addFields({name: `<:cxb:1172016413091831880> **| Cupom:**`,value: `${dbc.get(`${cupom}.idcupom`)}`})
                                     .addFields({name: `<:copy:1172263103031951481> **| Desconto:**`,value: `${dbc.get(`${cupom}.desconto`)}.00%`})
                                     .addFields({name: `<:cedulas:1172016314743787550> **| Preço Atual:**`,value: `${precoalt} `})
                                     .setColor(config.get(`color`))
                                     .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                                   msg.edit({ embeds: [embedss2], components: [row], content: `<@${interaction.user.id}>`, fetchReply: true })
                                   dbc.set(`${cupom}.quantidade`, `${qtdalt}`)
                                 }
                               }
                              }) 
                            })
                          }
                                    
                           if (intera2.customId === 'cancelarboton') {
                             const embedcancelar2 = new Discord.EmbedBuilder()
                            .setTitle(`${config.get(`title`)}`)
                            .setDescription(`<:1150929660490809404:1172016427755114566> **| Você acabou cancelando a Compra, e o Stock foi restornado!**`)
                            .setColor(config.get(`color`))
                            .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                            interaction.user.send({embeds: [embedcancelar2]})
                             db3.delete(`${data_id}`)
                             if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) { c.delete(); }
                           }

                           if (intera2.customId === "continuarboton") {
                             
                                 db3.set(`${data_id}.status`, `Pendente (2)`)
                                 const attachment = confud.pix.qrcode
                                 const row = new Discord.ActionRowBuilder()
                                   .addComponents(
                                     new Discord.ButtonBuilder()
                                       .setCustomId('codigo')
                                       
                                       .setLabel("PIX Copiar e Colar")
                                       .setStyle(Discord.ButtonStyle.Secondary),
                                 )
                                   .addComponents(
                                     new Discord.ButtonBuilder()
                                       .setCustomId('qrcode')
                                       
                                       .setLabel("Pagar com QR Code")
                                       .setStyle(Discord.ButtonStyle.Secondary),
                                 )
                                 .addComponents(
                                    new Discord.ButtonBuilder()
                                      .setCustomId('cancelarpix')
                                      
                                      .setLabel("Cancelar a Compra")
                                      .setStyle(Discord.ButtonStyle.Secondary),
                                ).addComponents(
                                    new Discord.ButtonBuilder()
                                      .setCustomId('aprovarcompra')
                                      
                                      .setLabel("Aprovar a Compra")
                                      .setStyle(Discord.ButtonStyle.Secondary),
                                );;
                                const embed = new Discord.EmbedBuilder()
                                  .setTitle(`${config.get(`title`)}`)
                                  .setDescription(`
\`\`\`
Após o pagamento, por favor, pedimos que envie o comprovante de transferência, para que verificarmos se esta tudo certo!
\`\`\``)
                                  .addFields({name: `<:copy:1172263103031951481> **| Nome:**`,value: `${eprod.nome}`})
                                  .addFields({name: `<:cxb:1172016413091831880> **| Quantidade:**`,value: `${quantidade1}`})
                                  .addFields({name: `<:cedulas:1172016314743787550> **| Valor:**`,value: `${precoalt} `}) 
                                  .addFields({name: `<:rg:1172016364014284820> **| ID da compra:**`,value: `${data_id}`}) 
                                  .setColor(config.get(`color`))
                                  .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                                msg.edit({ embeds: [embed], content: `<@${interaction.user.id}>`, components: [row] }).then(msg => {

                                const collector = msg.channel.createMessageComponentCollector();
                                                    collector.on("collect", (interaction) => {
                                                        if(interaction.customId === "aprovarcompra"){
                                                            if(interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`) return interaction.reply(`<:1150929660490809404:1172016427755114566> | Você não tem permissão de aprovar!`)
                                                         const vendadel = setTimeout(function () {
                                    if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) { c.delete(); }}, 60000)
                                   const a = db.get(`${severi}.conta`);
                                   const canalif1 = interaction.client.channels.cache.get(config.canallogs);
                                     db2.add("pedidostotal", 1)
                                     db2.add("gastostotal", Number(precoalt))
                                     db2.add(`${moment().format('L')}.pedidos`, 1)
                                     db2.add(`${moment().format('L')}.recebimentos`, Number(precoalt))
                                     db2.add(`${ususus.id}.gastosaprovados`, Number(precoalt))
                                     db2.add(`${ususus.id}.pedidosaprovados`, 1)

                                     if (a < quantidade1) {}
                                     
                                     else {
                                           const removed = a.splice(0, Number(quantidade1));
                                            db.set(`${severi}.conta`, a);
                                             const embedentrega = new Discord.EmbedBuilder()
                                               .setTitle(`${config.get(`title`)} | Seu produto`)
                                               .setDescription(`**<:rg:1172016364014284820> | Produtos:** \n  \`\`\`📦 | ${removed.join("\n")}\`\`\`\n**<:rg:1172016364014284820> **| ID da compra:**:** ${data_id} `)
                                               .setImage(`https://static-prod.adweek.com/wp-content/uploads/2021/07/DiscordLogo-652x367.jpg`)
                                               .setColor(config.get(`color`))
                                               .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                                             ususus.send({ embeds: [embedentrega] })
                                              db3.set(`${data_id}.status`, `Concluido`)
                                              msg.channel.send("<:1150929512859697152:1172016425469231196> **| Pagamento aprovado verifique a sua DM!**")
                                              msg.channel.send(`<:copy:1172263103031951481> **| ID Da compra:** ||${data_id}||`)
                                              msg.channel.send("<:info2:1172016307814801408> **| Carrinho fechara em 3 minutos.**")
                                              const roleId = config.get('role');
                                              const role = interaction.guild.roles.cache.get(roleId);
                                              
                                              if (role) {
                                                
                                                const membro = interaction.guild.members.cache.get(ususus.id);
                                              
                                                
                                                if (membro) {
                                                  
                                                  membro.roles.add(role)
                                                    .then(() => {
                                                     
                                                      console.log('Função adicionada com sucesso.');
                                                    })
                                                    .catch(error => {
                                                     
                                                      console.error('Erro ao adicionar a função:', error);
                                                    });
                                                } else {
                                                  console.error('Membro não encontrado.');
                                                }
                                              } else {
                                                console.error('Função não encontrada.');
                                              }

                                                              
                                             let sleep = async (ms) => await new Promise(r => setTimeout(r,ms));
                                             let avaliacao = "Nenhuma avaliação enviada..."
                                             const embed = msg.reply({ embeds: [
                                                new Discord.EmbedBuilder()
                                               .setTitle(`Smith Tools | Avaliação`)
                                               .addFields({name: `<:copy:1172263103031951481> **| Informações:**`, value: `Abra Ticket para quaisquer duvida!`})
                                               .addFields({name: `<:estrela:1172016359958401125> **| Estrelas:**`,value: `Aguardando...`})
                                               .setColor(config.get(`color`))],
                                               })
                                        
                                             const interacaoavaliar = msg.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, });
                                             interacaoavaliar.on("collect", async (interaction) => {
                                               if (interaction.user.id != interaction.user.id) {
                                                 return;
                                               }
                             
                                            
                                               })
                                                                
                                               const embedaprovadolog = new Discord.EmbedBuilder()
                                               .setTitle(`Smith Tools | Compra Aprovada`)
                                               .addFields({name: `<:member:1172016301351374918> **| Comprador:**`,value:  `<@${interaction.user.id}>`})
                                               .addFields({name: `<:calendary:1172016304706818169> **| Data da compra:**`,value: `${moment().format('LLLL')}`})
                                               .addFields({name: `<:carrinho:1172016409556045896> **| Produto:**`, value: `${eprod.nome}`})
                                               .addFields({name: `<:cxb:1172016413091831880> **| Quantidade:**`,value: `${quantidade1}x`})
                                               .addFields({name: `<:cedulas:1172016314743787550> **| Valor Pago:**`,value: `R$${precoalt}`})
                                               .addFields({name: `<:rg:1172016364014284820> **| ID da compra:**:`,value: `${data_id}`})
                                               .setColor(config.get(`color`))
                                               .setThumbnail(
        `${interaction.user.displayAvatarURL({
          dynamic: true,
          format: "png",
          size: 4096,
        })}`
      )
                                             const channesls = interaction.client.channels.cache.get(config.get(`logs`))
                                             channesls.send({embeds: [embedaprovadolog]})
                                               const canalif = interaction.client.channels.cache.get(config.get(`logs_staff`))
                                               canalif.send({ embeds: [
                                                new Discord.EmbedBuilder()
                                                 .setTitle(`${config.get(`title`)} | Compra Aprovada`)
                                                 .addFields({name: `<:member:1172016301351374918> **| Comprador:**`,value: `${interaction.user}`})
                                                 .addFields({name: `<:calendary:1172016304706818169> **| Data da compra:**`,value: `${moment().format('LLLL')}`})
                                                 .addFields({name: `<:carrinho:1172016409556045896> **| Produto:**`, value: `${eprod.nome}`})
                                                 .addFields({name: `<:cxb:1172016413091831880> **| Quantidade:**`,value: `${quantidade1}x`})
                                                 .addFields({name: `<:cedulas:1172016314743787550> **| Preço:**`,value: `${precoalt}`})
                                                 .addFields({name: `<:rg:1172016364014284820> **| ID da compra:**:`,value: `${data_id}`})
                                                 .addFields({name: `<:config2:1168182783722664020> **| Produto Entregue:**`, value: `\`\`\`${removed.join(" \n")}\`\`\``})
                                                 .setColor(config.get(`color`))
                                                 .setThumbnail(
                                                      `${interaction.user.displayAvatarURL({
                                                        dynamic: true,
                                                        format: "png",
                                                     size: 4096,
                                                  })}`
                                                 )]})

                                                msg.edit({components:[]})
                                                        }   
                                                        }
                                                     if (interaction.customId === 'codigo') {
                                                      row.components[0].setDisabled(true)
                                                      msg.channel.send({
                                                        content:`<:pix:1172016367122264074> **| Chave Pix:** \`${confud.pix.chave_pix}\``
                                                      })
                                                       const embed = new Discord.EmbedBuilder()
                                                         .setTitle(`${config.get(`title`)}`)
                                                         .setDescription(`
\`\`\`
Após O pagamento receberá o produto em seu privado, recomendamos deixar a DM aberta para que receba o produto!
\`\`\``)
                                                         .addFields({name: `<:copy:1172263103031951481> **| Nome:**`,value: `${eprod.nome}`})
                                                         .addFields({name: `<:cxb:1172016413091831880> **| Quantidade:**`,value: `${quantidade1}`})
                                                         .addFields({name: `<:cedulas:1172016314743787550> **| Valor:**`,value: `${precoalt} `}) 
                                                         .addFields({name: `<:rg:1172016364014284820> **| ID da compra:**`,value: `${data_id}`}) 
                                                         .setColor(config.get(`color`))
                                                         .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                                                         
                                                         msg.edit({ embeds: [embed], content: `<@${interaction.user.id}>`, components: [row] })
                                                       }
                                                    
                                                       if (interaction.customId === 'qrcode') {
                                                        row.components[1].setDisabled(true)
                                                        const embed2 = new Discord.EmbedBuilder()
                                                          .setTitle(`${config.get(`title`)}`)
                                                          .setDescription(`
\`\`\`
Após o pagamento receberá o produto em seu privado, recomendamos deixar a DM aberta para que receba o produto!
\`\`\``)
                                                          .addFields({name: `<:copy:1172263103031951481> **| Nome:**`,value: `${eprod.nome}`})
                                                          .addFields({name: `<:cxb:1172016413091831880> **| Quantidade:**`,value: `${quantidade1}`})
                                                          .addFields({name: `<:cedulas:1172016314743787550> **| Valor:**`,value: `${precoalt} `}) 
                                                          .addFields({name: `<:rg:1172016364014284820> **| ID da compra:**`,value: `${data_id}`}) 
                                                          .setColor(config.get(`color`))
                                                          .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                                                        msg.edit({ embeds: [embed2], content: `<@${interaction.user.id}>`, components: [row] })
                                                        
                                                        const embed = new Discord.EmbedBuilder()
                                                          .setTitle(`${config.get(`title`)}`)
                                                          .setDescription(`<:copy:1172263103031951481> **| Aponte a camera do seu dispositivo para o QR-code e escaneio-o, feito isso basta efetuar o pagamento e aguardar alguns segundos.**`)
                                                          .setImage(confud.pix.qrcode)
                                                          .setColor(config.get(`color`))
                                                       msg.channel.send({ embeds: [embed]})
                                                       }
                                                    
                                                       if (interaction.customId === 'cancelarpix') {
                                                         const embedcancelar3 = new Discord.EmbedBuilder()
                            .setTitle(`${config.get(`title`)}`)
                            .setDescription(`<:1150929660490809404:1172016427755114566> **| Você acabou cancelando a Compra, e o estoque foi restornado!**`)
                            .setImage(`https://static-prod.adweek.com/wp-content/uploads/2021/07/DiscordLogo-652x367.jpg`)
                            .setColor(config.get(`color`))
                            .setThumbnail(
              `${interaction.user.displayAvatarURL({
                dynamic: true,
                format: "png",
                size: 4096,
              })}`
            )
                            interaction.user.send({embeds: [embedcancelar3]})
                                                         db3.delete(`${data_id}`)
                                                         if ((interaction.guild.channels.cache.find(c => c.topic === interaction.user.id))) { c.delete(); }
                                                        }
                                                      })
                                                    })
                                                  
             
                                           }
                                        })}
                                       
                                     
                                   )}})})})}}}}