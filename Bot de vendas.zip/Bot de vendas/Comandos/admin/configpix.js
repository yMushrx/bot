const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const config = new JsonDatabase({ databasePath:"./config.json" });
const perms = new JsonDatabase({ databasePath:"./databases/myJsonPerms.json" });

module.exports = {
    name: "configpix",  
    description: "「👑」Configure o pix", // Coloque a descrição do comando
    type: Discord.ApplicationCommandType.ChatInput,
    run: async(client, interaction, message, args) => {
      if(interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`) return interaction.reply(`<:1150929660490809404:1172016427755114566> | Você não está na lista de pessoas!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
      const row = new Discord.ActionRowBuilder()
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('pixxx')
            .setEmoji('<:config2:1168182783722664020>')
            .setLabel('Alterar Chave Pix')
            .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('qrcoddd')
            .setEmoji('<:config2:1168182783722664020>')
            .setLabel('Alterar QrCode')
            .setStyle(Discord.ButtonStyle.Secondary),
        )
        
        const embed = await interaction.reply({ embeds: [new Discord.EmbedBuilder()
          .setTitle(`${config.get(`title`)} | Configuração do bot`)
          .setDescription(`
          <:config2:1168182783722664020> **| Chave Pix: ${config.get(`pix.chave_pix`)}**
          <:config2:1168182783722664020> **| QrCode URL: ${config.get(`pix.qrcode`)}**`)
          .setColor(config.get(`color`))], components: [row]})
        const interação = embed.createMessageComponentCollector({ componentType: Discord.ComponentType.Button, });
          interação.on("collect", async (interaction) => {
           if (interaction.user.id != interaction.user.id) {
             return;
           }
           if (interaction.customId === "qrcoddd") {
            interaction.deferUpdate();
            interaction.channel.send("<:info2:1172016307814801408> **| Qual o novo QrCode.**").then(msg => {
             const filter = m => m.author.id === interaction.user.id;
             const collector = msg.channel.createMessageCollector({ filter, max: 1 });
               collector.on("collect", role => {
                role.delete()
                const newt = role.content
                config.set(`pix.qrcode`, newt)
                msg.edit("<:1150929512859697152:1172016425469231196> **| Alterado!**")
                           
                
                embed.edit({ embeds: [new Discord.EmbedBuilder()
                    .setTitle(`${config.get(`title`)} | Configuração do bot`)
                    .setDescription(`
                    <:config2:1168182783722664020> **| Chave Pix: ${config.get(`pix.chave_pix`)}**
                    <:config2:1168182783722664020> **| QrCode URL: ${config.get(`pix.qrcode`)}**`)
                    .setColor(config.get(`color`))
                ] })
                })
              })
            }


           if (interaction.customId === "pixxx") {
            interaction.deferUpdate();
            interaction.channel.send("<:info2:1172016307814801408> **| Qual a nova Chave Pix.**").then(msg => {
             const filter = m => m.author.id === interaction.user.id;
             const collector = msg.channel.createMessageCollector({ filter, max: 1 });
               collector.on("collect", role => {
                role.delete()
                const newt = role.content
                config.set(`pix.chave_pix`, newt)
                msg.edit("<:1150929512859697152:1172016425469231196> **| Alterado!**")
                           
                
                embed.edit({ embeds: [new Discord.EmbedBuilder()
                    .setTitle(`${config.get(`title`)} | Configuração do bot`)
                    .setDescription(`
                    <:config2:1168182783722664020> **| Chave Pix: ${config.get(`pix.chave_pix`)}**
                    <:config2:1168182783722664020> **| QrCode URL: ${config.get(`pix.qrcode`)}**`)
                    .setColor(config.get(`color`))
                ] })
                })
              })
            }
           })
         }
       };