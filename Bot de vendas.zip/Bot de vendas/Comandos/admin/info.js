const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const db3 = new JsonDatabase({ databasePath:"./databases/myJsonIDs.json" });
const config = new JsonDatabase({ databasePath:"./config.json" });

module.exports = {
    name: "info",
    description: "「👑」Visualizar as informações de alguma compra pelo bot", 
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "id",
            description: "Id de uma compra",
            type: Discord.ApplicationCommandOptionType.String,
            required: true,
        },
      ],
    run: async(client, interaction, message, args) => {
      const id2 = interaction.options.getString("id")
      if(id2 !== `${db3.get(`${id2}.id`)}`) return interaction.reply(`<:1150929660490809404:1172016427755114566> **| Esse ID de compra não é existente!**`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));

      const embed = new Discord.EmbedBuilder()
        .setTitle(`${config.get(`title`)} | Compra Aprovada`)
        .addFields({name:`<:config2:1168182783722664020> **| ID da compra:**:`,value: `${db3.get(`${id2}.id`)}`})
        .addFields({name:`<:config2:1168182783722664020> **| Status:**`,value: `${db3.get(`${id2}.status`)}`})
        .addFields({name:`<:config2:1168182783722664020> **| Comprador:**`,value: `<@${db3.get(`${id2}.userid`)}>`})
        .addFields({name:`<:config2:1168182783722664020> **| Id Comprador:**`, value:`${db3.get(`${id2}.userid`)}`})
        .addFields({name:`<:config2:1168182783722664020> **| Data da compra:**`, value:`${db3.get(`${id2}.dataid`)}`})
        .addFields({name:`<:config2:1168182783722664020> **| Produto:**`, value: `${db3.get(`${id2}.nomeid`)}`})
        .addFields({name:`<:config2:1168182783722664020> **| Quantidade:**`, value: `${db3.get(`${id2}.qtdid`)}`})
        .addFields({name:`<:config2:1168182783722664020> **| Preço:**`,value: `${db3.get(`${id2}.precoid`)}`})
        .setColor(config.get(`color`))
      interaction.reply({embeds: [embed], content: "<a:1151253910376415412:1171972808134377533> **| Encontrado!**"})
    }
}