const Discord = require("discord.js")
const wio = require("wio.db");
const config = new wio.JsonDatabase({ databasePath:"./config.json" });
const perms = new wio.JsonDatabase({ databasePath:"./databases/myJsonPerms.json" });
const db1 = new wio.JsonDatabase({ databasePath:"./databases/myJsonProdutos.json" });
const db2 = new wio.JsonDatabase({ databasePath:"./databases/myJsonCupons.json" });
const db3 = new wio.JsonDatabase({ databasePath:"./databases/gifts.json" });

module.exports = {
    name: "criados", // Coloque o nome do comando
    description: "「👑」Veja os produtos, gifts e cupons criados.", // Coloque a descrição do comando
    type: Discord.ApplicationCommandType.ChatInput,
    run: async (client, interaction, message) => {

        if(interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`) return interaction.reply(`<:1150929660490809404:1172016427755114566> **| Você não está na lista de pessoas!**`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
        
      const row = new Discord.ActionRowBuilder()
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('db1')
            .setEmoji('<:config2:1168182783722664020>')
            .setLabel('Ver Produtos')
            .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('db2')
            .setEmoji('<:config2:1168182783722664020>')
            .setLabel('Ver Cupons')
            .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId('db3')
            .setEmoji('<:config2:1168182783722664020>')
            .setLabel('Ver Gifts')
            .setStyle(Discord.ButtonStyle.Secondary),
        )
      
        const embed = new Discord.EmbedBuilder()
          .setDescription(`<:config2:1168182783722664020> **| Escolha o tipo de serviço que você deseja ver.**`)
          .setColor(config.get(`color`))
        const msg = await interaction.reply({ embeds: [embed], components: [row] })
        const filter = i => i.user.id === interaction.user.id
        const collector = msg.createMessageComponentCollector({ filter })
        collector.on("collect", async interaction => {
          if(interaction.customId.startsWith("db")) {
            interaction.deferUpdate()
            let dbs = interaction.customId
            let itens
            let local
            let status
            
            if(dbs == "db1") {
              if(db1.all().length == 0) return embn(`<:1150929660490809404:1171972797405352027> **| Não há nenhum produto criado** no momento!||`, msg)
              itens = db1.all()
              local = "Produtos"
              status = "nome"
            }
            if(dbs == "db2") {
              if(db2.all().length == 0) return embn(`<:1150929660490809404:1171972797405352027> **| Não há nenhum cupom criado no momento!**`, msg)
              itens = db2.all()
              local = "Cupons"
              status = "desconto"
            }
            if(dbs == "db3") {
              if(db3.all().length == 0) return embn(`<:1150929660490809404:1171972797405352027> **| Não há nenhum gift criado no momento!**`, msg)
              itens = db3.all()
              local = "Gifts"
              status = "status"
            }
              
            let texto = ""
            let quant = 1
      
            for(let i in itens) {
              let item = itens[i]
              let value = item.data[status]
              let extra = local == "Cupons" ? "% de desconto" : ""
              texto += `• **${item.ID}** (${value}${extra})\n`
              quant++
            }
        
            const embed = new Discord.EmbedBuilder()                       
              .setTitle(`${client.user.username} | ${local} Existentes`)
              .setDescription(texto)
              .setColor(config.get(`color`))
              .setTimestamp()
            msg.edit({ embeds: [embed] })
          }
        })
    }
}