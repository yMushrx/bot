const Discord = require("discord.js");
const { JsonDatabase } = require("wio.db");

const db = new JsonDatabase({
  databasePath: "./databases/myJsonDatabase.json",
});

module.exports = {
  name: "rank",
  description: "「👑」Visualize os ranks do servidor sobre compras.",
  type: Discord.ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    const grana = db
      .all()
      .filter((i) => i.data.gastosaprovados)
      .sort((a, b) => b.data.gastosaprovados - a.data.gastosaprovados);
    let texto = "";

    if (grana.length < 5) {
      interaction.reply({
        content: `<:1150929660490809404:1171972797405352027> **| Você não tem clientes o suficiente, atualmente temos apenas ${grana.length}/5 clientes.**`,
      });
      return;
    }

    for (let i = 0; i < grana.length; i++) {
      const pos = i + 1;
      const emoji = "<:cedulas:1172016314743787550>";
      const user = client.users.cache.get(grana[i].ID) || "Desconhecido#0";
      texto += `${pos}º | <@${user}> - R$ ${grana[i].data.gastosaprovados} ${emoji}\n`;
    }

    const rank = new Discord.EmbedBuilder()
      .setTitle(`${client.user.username} | Ranking de Clientes`)
      .setDescription(texto)
      .setThumbnail(interaction.client.user.displayAvatarURL());

    interaction.reply({ embeds: [rank] });
  },
};
