const Discord = require("discord.js");
const { JsonDatabase } = require("wio.db");
const config = new JsonDatabase({ databasePath: "./config.json" });
const perms = new JsonDatabase({
  databasePath: "./databases/myJsonPerms.json",
});
const db = new JsonDatabase({ databasePath: "./databases/myJsonCupons.json" });

module.exports = {
  name: "configcupom",
  description: "「👑」Configure os cupom",
  type: Discord.ApplicationCommandType.ChatInput, // Coloque a descrição do comando
  options: [
    {
      name: "id",
      description: "Id do cupom",
      type: Discord.ApplicationCommandOptionType.String,
      required: true,
    },
  ],

  run: async (client, interaction, message, args) => {
    const id2 = interaction.options.getString("id");
    if (interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`)
      return interaction
        .reply(`<:1150929660490809404:1172016427755114566> **| Você não está na lista de pessoas!**`)
        .then((msg) =>
          setTimeout(() => msg.delete().catch((err) => console.log(err)), 5000)
        );
    if (id2 !== `${db.get(`${id2}.idcupom`)}`)
      return interaction
        .reply(`<:1150929660490809404:1172016427755114566> **| Esse ID de cupom não é existente!**`)
        .then((msg) =>
          setTimeout(() => msg.delete().catch((err) => console.log(err)), 5000)
        );

    const adb = id2;
    const row = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("qtdcupom")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Quantidade")
          .setStyle(Discord.ButtonStyle.Secondary)
      )
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("mincupom")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Mínimo")
          .setStyle(Discord.ButtonStyle.Secondary)
      )
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("pctcupom")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Porcentagem")
          .setStyle(Discord.ButtonStyle.Secondary)
      )
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("delcupom")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Excluir")
          .setStyle(Discord.ButtonStyle.Secondary)
      )
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("relcupom")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Atualizar")
          .setStyle(Discord.ButtonStyle.Secondary)
      );

    const msg = await interaction.reply({
      embeds: [
        new Discord.EmbedBuilder()
          .setTitle(`${config.get(`title`)} | Configurando o(a) ${adb}`)
          .setDescription(
            `
            <:config2:1168182783722664020> **| Quantidade: ${db.get(`${adb}.quantidade`)}**
           <:config2:1168182783722664020> **| Mínimo: ${db.get(
            `${adb}.minimo**`
          )} 
          <:config2:1168182783722664020> **| Porcentagem: ${db.get(`${adb}.desconto`)}%**`
          )
          .setThumbnail(interaction.client.user.displayAvatarURL())
          .setColor(config.get(`color`)),
      ],
      components: [row],
    });
    const interação = msg.createMessageComponentCollector({
      componentType: Discord.ComponentType.Button,
    });
    interação.on("collect", async (interaction) => {
      if (interaction.user.id != interaction.user.id) {
        return;
      }

      if (interaction.customId === "delcupom") {
        msg.delete();
        interaction.channel.send(
          "<a:1151253910376415412:1171972808134377533> **| Excluido!**"
        );
        db.delete(`${adb}`);
      }
      if (interaction.customId === "qtdcupom") {
        interaction.deferUpdate();
        interaction.channel
          .send("<:info2:1172016307814801408> **| Qual a nova quantidade de usos?**")
          .then((msg) => {
            const filter = (m) => m.author.id === interaction.user.id;
            const collector = msg.channel.createMessageCollector({
              filter,
              max: 1,
            });
            collector.on("collect", (message) => {
              message.delete();
              if (isNaN(message.content))
                return msg.edit(
                  "<:1150929660490809404:1172016427755114566> **| Não coloque nenhum caractere especial além de números.**"
                );
              db.set(`${adb}.quantidade`, `${message.content}`);
              msg.edit("<a:1151253910376415412:1171972808134377533> **| Alterado!**");
            });
          });
      }
      if (interaction.customId === "mincupom") {
        interaction.deferUpdate();
        interaction.channel
          .send("<:info2:1172016307814801408> **| Qual o novo mínimo para uso em?**")
          .then((msg) => {
            const filter = (m) => m.author.id === interaction.user.id;
            const collector = msg.channel.createMessageCollector({
              filter,
              max: 1,
            });
            collector.on("collect", (message) => {
              message.delete();
              db.set(`${adb}.minimo`, `${message.content.replace(",", ".")}`);
              msg.edit("<a:1151253910376415412:1171972808134377533> **| Alterado!**");
            });
          });
      }
      if (interaction.customId === "pctcupom") {
        interaction.deferUpdate();
        interaction.channel
          .send("<:info2:1172016307814801408> **| Qual o novo desconto em porcentagem?**")
          .then((msg) => {
            const filter = (m) => m.author.id === interaction.user.id;
            const collector = msg.channel.createMessageCollector({
              filter,
              max: 1,
            });
            collector.on("collect", (message) => {
              message.delete();
              if (isNaN(message.content))
                return msg.edit(
                  "<:1150929660490809404:1172016427755114566> **| Não coloque nenhum caractere especial além de números.**"
                );
              db.set(`${adb}.desconto`, `${message.content}`);
              msg.edit("<a:1151253910376415412:1171972808134377533> **| Alterado!**");
            });
          });
      }
      if (interaction.customId === "relcupom") {
        interaction.deferUpdate();
        const embed = new Discord.EmbedBuilder()
          .setTitle(`${config.get(`title`)} | Configurando o(a) ${adb}`)
          .setDescription(
            `
             <:cxb:1172016413091831880> **| Quantidade: ${db.get(`${adb}.quantidade`)}**
<a:1151253910376415412:1171972808134377533> **| Mínimo: ${db.get(`${adb}.minimo`)}**
<:cedulas:1172016314743787550> **| Desconto: ${db.get(`${adb}.desconto`)}%**`
          )
          .setThumbnail(interaction.client.user.displayAvatarURL())
          .setColor(config.get(`color`));
        msg.edit({ embeds: [embed] });
        interaction.channel.send(
          "<a:1151253910376415412:1171972808134377533> **| Atualizado!**"
        );
      }
    });
  },
};
