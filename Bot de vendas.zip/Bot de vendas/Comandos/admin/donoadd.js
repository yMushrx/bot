const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const perms = new JsonDatabase({ databasePath:"./databases/myJsonPerms.json" });
const config = new JsonDatabase({ databasePath:"./config.json" });

module.exports = {
    name: "donoadd",  
    description: "「👑」Adicionar algum administrador para configurar o bot", 
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "pessoa",
            description: "Adicione essa Pessoa",
            type: Discord.ApplicationCommandOptionType.User,
            required: true,
        }
    ],

    run: async(client,interaction, message, args) => {
      const user2 = interaction.options.getUser("pessoa")
      const user = user2.id
      if (interaction.user.id !== `${config.get(`owner`)}`) return interaction.reply(`<:1150929660490809404:1172016427755114566> | Apenas o criador do bot pode usar isso!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
      if(user === `${config.get(`owner`)}`) return interaction.reply(`<:1150929660490809404:1172016427755114566> | Essa pessoa já é o dono do bot!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
      if(isNaN(user)) return interaction.reply(`<:1150929660490809404:1172016427755114566> | Você só pode adicionar IDs!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
        
      interaction.reply(`<a:1151253910376415412:1171972808134377533> | Permissão de dono adicionada!`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
      config.set(`owner`, user)
      if(user === `${perms.get(`${user}_id`)}`) return
       else {
        perms.set(`${user}_id`, user)
       }
      }
     }