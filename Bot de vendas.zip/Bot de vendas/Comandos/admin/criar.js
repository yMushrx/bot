const Discord = require("discord.js");
const { JsonDatabase } = require("wio.db");
const config = new JsonDatabase({ databasePath: "./config.json" });
const perms = new JsonDatabase({
  databasePath: "./databases/myJsonPerms.json",
});
const db = new JsonDatabase({
  databasePath: "./databases/myJsonProdutos.json",
});

module.exports = {
  name: "criar", // Coloque o nome do comando
  description: "「👑」Utilizar para criar algum produto.", // Coloque a descrição do comando
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "id",
      description: "Id do produto",
      type: Discord.ApplicationCommandOptionType.String,
      required: true,
    },
  ],

  run: async (client, interaction, message) => {
    const id2 = interaction.options.getString("id");
    if (interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`)
      return interaction
        .reply(`:pushpin: **| Você não está na lista de pessoas!**`)
        .then((msg) =>
          setTimeout(() => msg.delete().catch((err) => console.log(err)), 5000)
        );
    if (id2 === `${db.get(`${id2}.idproduto`)}`)
      return interaction
        .reply(`:pushpin: **| Esse ID de produto já é existente!**`)
        .then((msg) =>
          setTimeout(() => msg.delete().catch((err) => console.log(err)), 5000)
        );

    const row = new Discord.ActionRowBuilder().addComponents(
      new Discord.ButtonBuilder()
        .setCustomId(id2)
        .setLabel("Adicionar Ao Carrinho")
        
        .setStyle(3)
    );

    const adici = new Discord.EmbedBuilder()
      .setTitle(`${config.get(`title`)}`)
      .setDescription(
        `
\`\`\`
Sem descrição ainda...
\`\`\`
**:pushpin: | Nome:** __Sem nome ainda...__
**:pushpin: | Preço:** __10__
**:pushpin: | Estoque:** __0__`
      )
      .setColor(config.get(`color`))
      .setThumbnail(interaction.client.user.displayAvatarURL());
    interaction.reply({ embeds: [adici], components: [row] });

    const idproduto = id2;
    db.set(`${idproduto}.idproduto`, `${idproduto}`);
    db.set(`${idproduto}.nome`, `Sem nome ainda...`);
    db.set(`${idproduto}.desc`, `Sem descrição ainda...`);
    db.set(`${idproduto}.preco`, `10`);

    db.push(`${idproduto}.conta`, `${idproduto}`);
    const a = db.get(`${idproduto}.conta`);
    const removed = a.splice(0, 1);
    db.set(`${idproduto}.conta`, a);
  },
};
