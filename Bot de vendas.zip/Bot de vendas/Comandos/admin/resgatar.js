const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const config = new JsonDatabase({ databasePath:"./config.json" });
const db = new JsonDatabase({ databasePath:"./databases/gifts.json" });

module.exports = {
    name: "resgatar", 
    description: "「👑」Utilize para resgatar algum GIFT criado.", 
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
      {
          name: "codigo",
          description: "Digite o Codigo",
          type: Discord.ApplicationCommandOptionType.String,
          required: true,
      },
    ],
    run: async(client,interaction, message, args) => {

      const codigo = interaction.options.getString("codigo")
      
      if(codigo !== `${db.get(`${codigo}.idgift`)}`) return interaction.reply(`<:1150929660490809404:1172016427755114566> **| Gift inválido!**`)
      if(`${db.get(`${codigo}.status`)}` == `Resgatado`) return interaction.reply(`<:1150929660490809404:1172016427755114566> **| Gift já resgatado!**`)
      var texto = ""
      var quant = 1
      var estoque = `${db.get(`${codigo}.estoque`)}`.split(',');
            
      for(let i in estoque) {
        texto = `${texto}${quant}° | ${estoque[i]}\n`
        quant++
      }
      
      
      interaction.reply(`<:1150929512859697152:1172016425469231196> **| Resgatado com sucesso!**`)
      const embed = new Discord.EmbedBuilder()
          .setTitle(`${config.get(`title`)} | Gift Resgtado`)
          .addFields({name: `<:config2:1168182783722664020> Presentes:**`,value:  `\`\`\`${texto}\`\`\``})
          .addFields({ name: `<:config2:1168182783722664020> **| Código:**`, value: codigo})
          .setColor(config.get(`color`))
      interaction.user.send({embeds: [embed]})
      db.set(`${codigo}.status`, `Resgatado`)
      db.delete(`${codigo}.estoque`)
    }
  }      