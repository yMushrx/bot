const Discord = require("discord.js");
const { JsonDatabase } = require("wio.db");
const config = new JsonDatabase({ databasePath: "./config.json" });
const perms = new JsonDatabase({
  databasePath: "./databases/myJsonPerms.json",
});
const db = new JsonDatabase({
  databasePath: "./databases/myJsonProdutos.json",
});

module.exports = {
  name: "estoque",
  description: "「👑」Utilize para gerenciar o stock da loja",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "id",
      description: "Id de um produto",
      type: Discord.ApplicationCommandOptionType.String,
      required: true,
    },
  ],
  run: async (client, interaction, message, args) => {
    const id2 = interaction.options.getString("id");
    if (interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`)
      return interaction.reply(`<:1150929660490809404:1172016427755114566> **| Você não está na lista de pessoas!**`);
    if (id2 !== `${db.get(`${id2}.idproduto`)}`)
      return interaction.reply(`<:1150929660490809404:1172016427755114566> **| Esse ID de produto não é existente!**`);

    const adb = id2;
    const itens = db.get(`${adb}.conta`);
    const row = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("addestoque")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Adicionar Produto")
          .setStyle(Discord.ButtonStyle.Secondary)
      )
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("remestoque")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Remover Produto")
          .setStyle(Discord.ButtonStyle.Secondary)
      )
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("bckestoque")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Fazer Backup do Stock")
          .setStyle(Discord.ButtonStyle.Secondary)
      )
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("clestoque")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Excluir Os Produtos")
          .setStyle(Discord.ButtonStyle.Secondary)
      )
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("rlestoque")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Atualizar Stock")
          .setStyle(Discord.ButtonStyle.Secondary)
      );

    const msg = await interaction.reply({
      embeds: [
        new Discord.EmbedBuilder()
          .setTitle(`${config.get(`title`)} | Gerenciando o(a) ${adb}`)
          .setDescription(
            `
<:config2:1168182783722664020> **| Descrição:** ${db.get(`${adb}.desc`)}
<:copy:1172263103031951481> **| Nome:** ${db.get(`${adb}.nome`)}
<:cedulas:1172016314743787550> **| Preço:** ${db.get(`${adb}.preco`)} 
<:cxb:1172016413091831880> **| Estoque:** ${db.get(`${adb}.conta`).length}`
          )
          .setThumbnail(interaction.client.user.displayAvatarURL())
          .setColor(config.get(`color`)),
      ],
      components: [row],
    });
    const interação = msg.createMessageComponentCollector({
      componentType: Discord.ComponentType.Button,
    });
    interação.on("collect", async (interaction) => {
      if (interaction.user.id != interaction.user.id) {
        return;
      }

      if (interaction.customId === "addestoque") {
        interaction.deferUpdate();
        interaction.channel
          .send("<:config2:1168182783722664020> **| Envie os novos produtos no chat!**")
          .then((msg) => {
            const filter = (m) => m.author.id === interaction.user.id;
            const collector = msg.channel.createMessageCollector({ filter });
            collector.on("collect", (message) => {
              const content = message.content.split("\n");
              const contasnb = message.content.split("\n").length;
              var contas = content;
              var etapa = 0;
              var etapaf = contasnb;
              collector.stop();
              message.delete();
              const timer = setInterval(async function () {
                if (etapa === etapaf) {
                  msg.edit(
                    `<a:1151253910376415412:1171972808134377533> **| Pronto, \`${etapaf}\`\ Produtos foram adicionados com sucesso!**`
                  );
                  clearInterval(timer);
                  return;
                }
                const enviando = contas[etapa];
                db.push(`${adb}.conta`, `${enviando}`);
                etapa = etapa + 1;
              }, 100);
            });
          });
      }
      if (interaction.customId === "remestoque") {
        interaction.deferUpdate();
        interaction.channel
          .send("<:config2:1168182783722664020> **| Envie a linha do produto que você quer remover!**")
          .then((msg) => {
            const filter = (m) => m.author.id === interaction.user.id;
            const collector = msg.channel.createMessageCollector({
              filter,
              max: 1,
            });
            collector.on("collect", (message1) => {
              const a = db.get(`${adb}.conta`);
              a.splice(message1.content, 1);
              db.set(`${adb}.conta`, a);
              message1.delete();
              msg.edit(
                `<a:1151253910376415412:1171972808134377533> **| O Produto número \`${message1}\`\ foi removido com sucesso!**`
              );
            });
          });
      }
      if (interaction.customId === "clestoque") {
        interaction.deferUpdate();
        const a = db.get(`${adb}.conta`);
        const removed = a.splice(0, `${db.get(`${adb}.conta`).length}`);
        db.set(`${adb}.conta`, a);
        interaction.channel.send(
          "<a:1151253910376415412:1171972808134377533> **| Estoque limpo!**"
        );
      }
      if (interaction.customId === "bckestoque") {
        interaction.deferUpdate();
        interaction.channel.send(
          "<a:1151253910376415412:1171972808134377533> **| Enviado com sucesso!**"
        );
        var quantia = 1;
        var contas = `${db.get(`${adb}.conta`)}`.split(",");
        var backup = `• ${contas.join(`\n• `)}`;
        const embed = new Discord.EmbedBuilder()
          .setTitle(`${config.get(`title`)} | Backup feito`)
          .setDescription(`\`\`\`${backup} \`\`\``)
          .setColor(config.get(`color`));
        interaction.user.send({ embeds: [embed] });
      }

      if (interaction.customId === "rlestoque") {
        interaction.deferUpdate();
        const embed = new Discord.EmbedBuilder()
          .setTitle(`${config.get(`title`)} | Gerenciando o(a) ${adb}`)
          .setDescription(
            `
            <:config2:1168182783722664020> **| Descrição:** ${db.get(`${adb}.desc`)}
<:copy:1172263103031951481> **| Nome:** ${db.get(`${adb}.nome`)}
<:cedulas:1172016314743787550> **| Preço:** ${db.get(`${adb}.preco`)} 
<:cxb:1172016413091831880> **| Estoque:** ${db.get(`${adb}.conta`).length}`
          )
          .setThumbnail(interaction.client.user.displayAvatarURL())
          .setColor(config.get(`color`));
        msg.edit({ embeds: [embed] });
        interaction.channel.send(
          "<a:1151253910376415412:1171972808134377533> **| Atualizado!**"
        );
      }
    });
  },
};
