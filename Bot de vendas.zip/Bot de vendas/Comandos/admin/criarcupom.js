const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const config = new JsonDatabase({ databasePath:"./config.json" });
const perms = new JsonDatabase({ databasePath:"./databases/myJsonPerms.json" });
const db = new JsonDatabase({ databasePath:"./databases/myJsonCupons.json" });

module.exports = {
    name: "criarcupom", 
    description: "「👑」Utilize para criar algum cumpom na store", 
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "id",
            description: "Id do cupom",
            type: Discord.ApplicationCommandOptionType.String,
            required: true,
        }
    ],
    run: async (client, interaction, message) => {

        const id2 = interaction.options.getString("id")
      if(interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`) return interaction.reply(`:pushpin: **| Você não está na lista de pessoas!**`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));
      if(id2 === `${db.get(`${id2}.idcupom`)}`) return interaction.reply(`:pushpin: **| Esse ID de cupom já é existente!**`).then(msg => setTimeout(() => msg.delete().catch(err => console.log(err)), 5000));

      interaction.reply(":pushpin: **| Criado com sucesso!**")
      const idcupom = id2
        db.set(`${idcupom}.idcupom`, `${idcupom}`)
        db.set(`${idcupom}.quantidade`, `0`)
        db.set(`${idcupom}.minimo`, `20`)
        db.set(`${idcupom}.desconto`, `50`)
       }
     }