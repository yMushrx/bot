const Discord = require("discord.js");
const { JsonDatabase } = require("wio.db");
const config = new JsonDatabase({ databasePath: "./config.json" });
const perms = new JsonDatabase({
  databasePath: "./databases/myJsonPerms.json",
});
const db = new JsonDatabase({
  databasePath: "./databases/myJsonProdutos.json",
});

module.exports = {
  name: "config",
  description: "「👑」Configure um produto", // Coloque a descrição do comando
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "id",
      description: "Id do produto",
      type: Discord.ApplicationCommandOptionType.String,
      required: true,
    },
  ],
  run: async (client, interaction, message, args) => {
    const id2 = interaction.options.getString("id");
    if (interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`)
      return interaction
        .reply(`<:1150929660490809404:1172016427755114566> **| Você não está na lista de pessoas!**`)
        .then((msg) =>
          setTimeout(() => msg.delete().catch((err) => console.log(err)), 5000)
        );
    if (id2 !== `${db.get(`${id2}.idproduto`)}`)
      return interaction
        .reply(`<:1150929660490809404:1172016427755114566> **| Esse ID de produto não é existente!**`)
        .then((msg) =>
          setTimeout(() => msg.delete().catch((err) => console.log(err)), 5000)
        );

    const adb = id2;
    const row = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("descgerenciar")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Descrição")
          .setStyle(Discord.ButtonStyle.Secondary)
      )
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("nomegerenciar")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Nome")
          .setStyle(Discord.ButtonStyle.Secondary)
      )
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("precogerenciar")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Preço")
          .setStyle(Discord.ButtonStyle.Secondary)
      )
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("deletegerenciar")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Excluir")
          .setStyle(Discord.ButtonStyle.Secondary)
      )
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("rlgerenciar")
          .setEmoji("<:config2:1168182783722664020>")
          .setLabel("Atualizar")
          .setStyle(Discord.ButtonStyle.Secondary)
      );

    const msg = await interaction.reply({
      embeds: [
        new Discord.EmbedBuilder()

          .setTitle(`${config.get(`title`)} | Configurando o(a) ${adb}`)

          .setDescription(
            `
                <:bloco:1168179922649489429> | Descrição: \`\`\` ${db.get(`${adb}.desc`)}\`\`\`
                <:copy:1172263103031951481> | Nome: ${db.get(`${adb}.nome`)}
                <:cedulas:1172016314743787550> | Preço: ${db.get(`${adb}.preco`)} 
                <:cxb:1172016413091831880> | Estoque: ${db.get(`${adb}.conta`).length}`
          )
          .setThumbnail(interaction.client.user.displayAvatarURL())
          .setColor(config.get(`color`)),
      ],
      components: [row],
    });

    const filter = (i) => i.user.id === interaction.user.id;
    const interação = msg.createMessageComponentCollector({ filter });

    interação.on("collect", async (interaction) => {
      if (interaction.user.id != interaction.user.id) {
        return;
      }

      if (interaction.customId === "deletegerenciar") {
        msg.delete();
        msg.channel.send("<:lixo:1172221753393676381> **| Excluido com sucesso!**");
        db.delete(adb);
      }
      if (interaction.customId === "precogerenciar") {
        interaction.deferUpdate();
        interaction.channel.send("<:info2:1172016307814801408> **| Qual o novo preço?**").then((msg) => {
          const filter = (m) => m.author.id === interaction.user.id;
          const collector = msg.channel.createMessageCollector({
            filter,
            max: 1,
          });
          collector.on("collect", (message) => {
            message.delete();
            db.set(`${adb}.preco`, `${message.content.replace(",", ".")}`);
            msg.edit("<:config2:1172016353692110870> **| Alterado!**");
          });
        });
      }
      if (interaction.customId === "nomegerenciar") {
        interaction.deferUpdate();
        interaction.channel.send("<:info2:1172016307814801408> **| Qual o novo nome?**").then((msg) => {
          const filter = (m) => m.author.id === interaction.user.id;
          const collector = msg.channel.createMessageCollector({
            filter,
            max: 1,
          });
          collector.on("collect", (message) => {
            message.delete();
            db.set(`${adb}.nome`, `${message.content}`);
            msg.edit("<:config2:1172016353692110870> **| Alterado!**");
          });
        });
      }
      if (interaction.customId === "descgerenciar") {
        interaction.deferUpdate();
        interaction.channel.send("<:info2:1172016307814801408> **| Qual a nova descrição?**").then((msg) => {
          const filter = (m) => m.author.id === interaction.user.id;
          const collector = msg.channel.createMessageCollector({
            filter,
            max: 1,
          });
          collector.on("collect", (message) => {
            message.delete();
            db.set(`${adb}.desc`, `${message.content}`);
            msg.edit("<:config2:1172016353692110870> | Alterado!");
          });
        });
      }
      if (interaction.customId === "rlgerenciar") {
        interaction.deferUpdate();
        const embed = new Discord.EmbedBuilder()
          .setTitle(`${config.get(`title`)} | Configurando o(a) ${adb}`)
          .setDescription(
            `
<:bloco:1168179922649489429> | Descrição: \`\`\` ${db.get(`${adb}.desc`)}\`\`\`
<:copy:1172263103031951481> | Nome: ${db.get(`${adb}.nome`)}
<:cedulas:1172016314743787550> | Preço: ${db.get(`${adb}.preco`)} 
<:cxb:1172016413091831880> | Estoque: ${db.get(`${adb}.conta`).length}`
          )
          .setThumbnail(interaction.client.user.displayAvatarURL())
          .setColor(config.get(`color`));
        msg.edit({ embeds: [embed] });
        interaction.channel.send("<:config2:1172016353692110870> **| Atualizado!**");
      }
    });
  },
};
