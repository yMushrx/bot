const Discord = require("discord.js");
const { JsonDatabase } = require("wio.db");
const config = new JsonDatabase({ databasePath: "./config.json" });
const perms = new JsonDatabase({
  databasePath: "./databases/myJsonPerms.json",
});
const db = new JsonDatabase({
  databasePath: "./databases/myJsonPainel.json",
});
const debe = require("../../databases/myJsonPainel.json")
const prod = new JsonDatabase({
  databasePath: "./databases/myJsonProdutos.json",
});

module.exports = {
  name: "set-painel",
  description: "「👑」Utilize para setar o painel criado.", // Coloque a descrição do comando
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "id",
      description: "Id do Painel",
      type: Discord.ApplicationCommandOptionType.String,
      required: true,
    },
  ],
  run: async (client, interaction, message, args) => {
    const id2 = interaction.options.getString("id");
    const id = id2
    if (interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`)
      return interaction
        .reply(`<:1150929660490809404:1172016427755114566> **| Você não está na lista de pessoas!**`)
        .then((msg) =>
          setTimeout(() => msg.delete().catch((err) => console.log(err)), 5000)
        );

        if (id2 !== `${db.get(`${id2}.painelid`)}`)
        return interaction
          .reply(`<:1150929660490809404:1172016427755114566> **| Esse ID de produto não existe!**`)
          .then((msg) =>
            setTimeout(() => msg.delete().catch((err) => console.log(err)), 5000)
          );

          const idproduto = db.get(`${id}.idproduto`);

          const fields = [];
          for (const produtoId in idproduto) {
              const produtoInfo = prod.get(produtoId);
              if (produtoInfo) {
                  fields.push({
                      label: produtoInfo.nome,
                      value: produtoInfo.idproduto,
                      emoji:`<:carrinho:1172016409556045896>`,
                      description: `<:cedulas:1172016314743787550> **| Valor: ${produtoInfo.preco} - <:cxb:1172016413091831880>| Estoque: ${produtoInfo.conta.length}**`,
                  });
              }
          }

          const embeds = new Discord.EmbedBuilder()
          .setTitle(`${db.get(`${id}.configuração.titulo`)}`)
          .setColor(`${db.get(`${id}.configuração.Cor_Embed`)}`)
          .setDescription(`\`\`\` ${db.get(`${id}.configuração.descrição`)} \`\`\``)
          .setFooter({ text: `${db.get(`${id}.configuração.footer`)}`})
          .setThumbnail(interaction.client.user.displayAvatarURL())
          .setImage(`${db.get(`${id}.configuração.banner`)}`)

          
          const row = new Discord.ActionRowBuilder()
          .addComponents(
            new Discord.StringSelectMenuBuilder()
            .setPlaceholder(`${db.get(`${id}.configuração.placeholder`)}`)
            .setCustomId(`${id2}_select`)
            .addOptions(fields))

            
            interaction.channel.send({
                embeds:[embeds],
                components:[row]
            }).then(() => {
                interaction.reply({
                    content:"<:1150929512859697152:1172016425469231196> **| Setado com sucesso.**",
                    ephemeral:true
                })
            })

  }}