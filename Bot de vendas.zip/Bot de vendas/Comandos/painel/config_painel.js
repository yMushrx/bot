const Discord = require("discord.js");
const { JsonDatabase } = require("wio.db");
const config = new JsonDatabase({ databasePath: "./config.json" });
const perms = new JsonDatabase({
  databasePath: "./databases/myJsonPerms.json",
});
const db = new JsonDatabase({
  databasePath: "./databases/myJsonPainel.json",
});
const debe = require("../../databases/myJsonPainel.json")

const prod = new JsonDatabase({
  databasePath: "./databases/myJsonProdutos.json",
});


module.exports = {
  name: "config-painel",
  description: "「👑」Configurar algum painel de vendas.", // Coloque a descrição do comando
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "id",
      description: "Id do Painel",
      type: Discord.ApplicationCommandOptionType.String,
      required: true,
    },
  ],
  run: async (client, interaction, message, args) => {
    const id2 = interaction.options.getString("id");
    if (interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`)
      return interaction
        .reply(`<:1150929660490809404:1172016427755114566> **| Você não está na lista de pessoas!**`)
        .then((msg) =>
          setTimeout(() => msg.delete().catch((err) => console.log(err)), 5000)
        );

        if (id2 !== `${db.get(`${id2}.painelid`)}`)
        return interaction
          .reply(`<:1150929660490809404:1172016427755114566> **| Esse ID de produto não existe!**`)
          .then((msg) =>
            setTimeout(() => msg.delete().catch((err) => console.log(err)), 5000)
          );

        const row = 
        new Discord.ActionRowBuilder()
        .addComponents(
          new Discord.ButtonBuilder()
              .setLabel("Configurar embed")
              .setCustomId(`${id2}_config_painel_embed`)
              .setEmoji("<:config2:1168182783722664020>")
              .setStyle(Discord.ButtonStyle.Secondary),
              new Discord.ButtonBuilder()
              .setLabel("Configurar Produtos")
              .setCustomId(`${id2}_configproductspainel`)
              .setEmoji("<:config2:1168182783722664020>")
              .setStyle(Discord.ButtonStyle.Secondary),
              new Discord.ButtonBuilder()
              .setLabel("DELETAR")
              .setCustomId(`${id2}_delete_painel`)
              .setEmoji("<:config2:1168182783722664020>")
              .setStyle(Discord.ButtonStyle.Secondary),
        );
        
          
      
          const adici = new Discord.EmbedBuilder()
            .setTitle(`${config.get(`title`)} | Gerenciar Painel`)
            .setDescription(`<:config2:1168182783722664020> **| Escolha oque deseja Gerenciar:**`)
            .setColor(config.get(`color`))
            .setFooter({ text: `${interaction.guild.name} - Todos os direitos reservados.`,iconURL: interaction.client.user.displayAvatarURL()})
          interaction.reply({ embeds: [adici], components: [row], ephemeral:true });

  }
};



//.addComponents(
//  new Discord.StringSelectMenuBuilder()
//  .setPlaceholder("Selecione um Produto")
//  .setCustomId("stringselectmenu_builder")
//  .addOptions(
//    db.get(`${id2}.produtos`).map((produto) => ({
//      label: produto.label,
//      description: `<:cedulas:1172016314743787550>| Valor: ${produto.description} - <:cxb:1172016413091831880>| Estoque: ${produto.contas.length}`,
//      value: produto.value,
//      emoji: produto.emoji,
//    })),
//    
//  )
//  
//);