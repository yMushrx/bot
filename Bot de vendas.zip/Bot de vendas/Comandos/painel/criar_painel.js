const Discord = require("discord.js");
const { JsonDatabase } = require("wio.db");
const config = new JsonDatabase({ databasePath: "./config.json" });
const perms = new JsonDatabase({ databasePath: "./databases/myJsonPerms.json" });
const db = new JsonDatabase({ databasePath: "./databases/myJsonPainel.json" });

const producs = require("../../databases/myJsonProdutos.json");
const dbpr = new JsonDatabase({ databasePath: "./databases/myJsonProdutos.json" });

module.exports = {
  name: "criar-painel",
  description: "「👑」Utilize para criar algum painel de produtos.",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "id",
      description: "Id do Painel",
      type: Discord.ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: "produto",
      description: "Selecione um produto",
      type: Discord.ApplicationCommandOptionType.String,
      required: true,
    },
  ],

  run: async (client, interaction, message) => {
    const id2 = interaction.options.getString("id");
    const produt1o = interaction.options.getString("produto")
    if (interaction.user.id !== `${perms.get(`${interaction.user.id}_id`)}`)
      return interaction
        .reply(`:pushpin: **| Você não está na lista de pessoas!**`)
        .then((msg) =>
          setTimeout(() => msg.delete().catch((err) => console.log(err)), 5000)
        );
        if (id2 === `${db.get(`${id2}.painelid`)}`)
        return interaction
          .reply(`:pushpin: **| Esse ID de produto já é existente!**`)
          .then((msg) =>
            setTimeout(() => msg.delete().catch((err) => console.log(err)), 5000)
          );
          
          if (produt1o === `${dbpr.get(`${produt1o}.idproduto`)}`)
        return interaction
          .reply(`:pushpin: **| Esse ID de produto já é existente!**`)
          .then((msg) =>
            setTimeout(() => msg.delete().catch((err) => console.log(err)), 5000)
          );

    const row = new Discord.ActionRowBuilder()
    .addComponents(
      new Discord.StringSelectMenuBuilder()
      .setPlaceholder("Selecione um Produto")
      .setCustomId("stringselectmenu_builder")
      .addOptions(
          {
            label: `${dbpr.get(`${produt1o}.nome`)}`,
            value: `${produt1o}`, 
            emoji: `<:carrinho:1172016409556045896>`,
            description: `<:cedulas:1172016314743787550> **| Valor:** ${dbpr.get(`${produt1o}.preco`)} - <:cxb:1172016413091831880> **| Estoque:** ${dbpr.get(`${produt1o}.conta`).length}`, //length
          }
      )
    );

    const adici = new Discord.EmbedBuilder()
      .setTitle(`Não Configurado ainda...`)
      .setDescription(
        `
\`\`\`
Sem descrição ainda...
\`\`\``
      )
      .setColor(config.get(`color`))
      .setImage(`${config.get(`thumbnail`)}`)
      .setFooter({ text:`${interaction.guild.name} - Todos Direitos Reservados`})
      .setThumbnail(interaction.client.user.displayAvatarURL());
    interaction.reply({ embeds: [adici], components: [row] });

    const idproduto = id2;

    const obj = {
      [idproduto]: idproduto
    };
    
    db.set(`${idproduto}.idproduto`, obj);

    db.set(`${idproduto}.painelid`, `${idproduto}`);
    db.set(`${idproduto}.configuração`, {
      Cor_Embed:`${config.get(`color`)}`,
      placeholder: `Selecione um Produto`,
      descrição:`Não Configurado ainda...`,
      titulo: `Não Configurado ainda...`,
      banner: `${config.get(`thumbnail`)}`,
      footer: `${interaction.guild.name} - Todos Direitos Reservados`
    })
    
  },
};

